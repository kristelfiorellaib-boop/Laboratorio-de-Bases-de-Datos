/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Datos;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

/**
 *
 * @author Unknown
 */
public class Conexion {

    public Conexion() {
    }
    
    public static Connection getConexion() throws SQLException
    {
        //Parametros para establecer la connexion
        String cadenaConexion = "jdbc:sqlserver://localhost:1433;" + //controlador jdbc, servidor y su puerto
                                "database=reservasvuelo;" + //Base de datos a usar 
                                "user=sa;" + //usuario de conexion a sql
                                "password=191809;" + //cave de conexion a sql
                                "encrypt=true;" + //conexion encriptada
                                "trustServerCertificate=true;" ; //certificado de confianza
        try {
            // establecer una conexion con los parametros dados
            Connection con = DriverManager.getConnection(cadenaConexion);
            return con;
        }catch (SQLException ex){
            JOptionPane.showMessageDialog(null, ex.toString());
            return null;
            
        }
    }
    
    
}
